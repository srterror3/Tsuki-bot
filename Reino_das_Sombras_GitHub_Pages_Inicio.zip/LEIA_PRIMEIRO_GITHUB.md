# Reino das Sombras — GitHub Pages (entrada pública)

Preparado para o repositório `srterror3/Tsuki-bot` usando os arquivos do portal Web RPG V1.

## O que é este pacote

Uma **página de entrada** estática, não um substituto do FastAPI.

- GitHub Pages oferece um endereço público permanente para o *link de entrada* do RPG.
- O painel **completo** continua no seu PC, usando `app/web_rpg.py` e `data/coelho.db`.
- O login Discord OAuth2, as fotos, itens, XP e missões acontecem no servidor do seu PC.
- O endereço HTTPS da API ainda precisa ser publicado por Cloudflare Tunnel (ou hospedagem equivalente).
- Com Cloudflare Quick Tunnel, o link de destino muda cada vez que o túnel é recriado. Para uma URL estável do *backend*, use um hostname permanente sob domínio próprio ou outra hospedagem pública estável.
- **Nunca** configure `RPG_PUBLIC_URL` com a URL do GitHub Pages. Ela deve ser a URL do servidor Python, pois o endpoint `/auth/callback` está no FastAPI.

## Como publicar no repositório GitHub

1. Faça backup do repositório se já contiver arquivos.
2. Pelo site do GitHub, abra `https://github.com/srterror3/Tsuki-bot`.
3. Crie uma pasta `docs` na raiz do repositório (ou copie para ela os arquivos `docs/index.html`, `docs/portal-config.js`, `docs/.nojekyll`). Não suba seu ZIP inteiro do bot.
4. Abra **Settings → Pages**.
5. Em **Build and deployment → Source**, selecione **Deploy from a branch**.
6. Selecione a branch principal, a pasta **`/docs`**, e clique **Save**.
7. O site deverá surgir em `https://srterror3.github.io/Tsuki-bot/` depois de o GitHub concluir o deploy. O endereço é previsto, não foi verificado como ativo.

No GitHub Free, GitHub Pages exige normalmente um repositório público. **Não torne público um repositório com segredos, banco real ou dados pessoais.** Se `Tsuki-bot` já tiver isso, crie um repositório público separado exclusivamente com os arquivos `docs/`.

## Como ativar o botão

1. Coloque o portal FastAPI para funcionar no seu PC: `INICIAR_RPG_WEB.bat`.
2. Configure uma URL HTTPS pública que aponte **somente** para `http://127.0.0.1:8765`.
3. No `.env.rpg` local, defina `RPG_PUBLIC_URL=https://SEU-ENDERECO-HTTPS` (sem barra final). Reinicie o portal.
4. No Discord Developer Portal, cadastre o redirecionamento `https://SEU-ENDERECO-HTTPS/auth/callback`.
5. Edite `docs/portal-config.js` no GitHub, colocando a **mesma URL do portal**:

```js
window.REINO_PORTAL_URL = "https://SEU-ENDERECO-HTTPS";
```

6. Ao publicar o arquivo, o botão da página GitHub Pages abrirá o portal, que fará o login Discord.
7. Para que `/portal` do Discord mande para o endereço do GitHub Pages, você pode futuramente configurar o comando para usar a landing page `https://srterror3.github.io/Tsuki-bot/`. Não altere `RPG_PUBLIC_URL` para esse valor.

## Segurança antes de tornar público

- NÃO publique arquivos `.env`, `.env.rpg`, `.sqlite`, `.db`, `*.pem`, `*.key`, `.venv/`, `data/`, fotos de jogadores ou sessões.
- O ZIP completo enviado do Coelho Manager contém credenciais locais; não o envie para um repositório público. **Regere o token do bot Discord caso ele tenha sido exposto.**
- Não publique a porta `8000` (admin). Somente a `8765` deve ficar por trás do túnel.
- Não cole Client Secret ou Discord Bot Token no GitHub, nem em `portal-config.js`.

## Observação de arquitetura

A interface real (`web/rpg_portal/index.html`, `app.js`) usa URLs relativas (`/api/portal/*`, `/login`, `/media/*`) e `credentials: 'same-origin'`. Copiar esses arquivos diretamente para GitHub Pages **não** daria login, inventário ou botões operacionais; por isso este pacote fornece uma página de entrada, e a aplicação real permanece unificada no FastAPI.
